package EU.ANONIMO.NAVEGADOR.BROWSER;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;


public class MainActivity extends Activity {
	



	public static final int MENU1 = Menu.FIRST; // mensagem
	public static final int MENU2 = Menu.FIRST + 1; // sair
	public static final int MENU3 = Menu.FIRST + 3;// op珲es
	public static final int MENU4 = Menu.FIRST + 4;// op珲es



Toolbar anonimo_aba_top;

    WebView anonimoweb;
    EditText ed1;
    Button bt1;
    String Address;
    String add;
    ProgressBar mprogressobar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
       
		
        anonimoweb = (WebView)findViewById(R.id.webView1);
		
        ed1 = (EditText)findViewById(R.id.editText1);
		
        mprogressobar = (ProgressBar)findViewById(R.id.progressBar1);
		
        mprogressobar.setVisibility(View.GONE);

     


                
                

		Button sair = (Button) 
                findViewById(R.id.btsair);
	
	sair.setOnClickListener(new View.OnClickListener()
 {
			
			@Override
			public void onClick(View v) {
				
				finish();
			}
		});


                
                
             
                
                
                   Button voltar = (Button)           
                  findViewById(R.id.btvoltar);       
        
		voltar.setOnClickListener(new View.OnClickListener()

			{
				@Override 
				public void onClick(View v)

				{
//verifica se é possivel voltar e se possivel ele irá redirecionar o Browser a pagina anterior

					if(anonimoweb.canGoBack()){
                   		anonimoweb.goBack();}}});



                                
                                
                                

                     Button avancar = (Button)
                     findViewById(R.id.btavancar);  
		
                     avancar.setOnClickListener(new View.OnClickListener()

			{
				@Override

				public void onClick(View v)

				{
//Verifica se é possível avançar. Em caso positivo, irá redirecionar o Browser para a página posterior

					if (anonimoweb.canGoForward()){
						anonimoweb.goForward();}}  });



                                                
                                                
                                                
                        Button atualizar = (Button)
                        findViewById(R.id.btatualizar);      
        

		atualizar.setOnClickListener(new View.OnClickListener()

			{
				@Override public void onClick(View v)

				{
//Recarrega a página

					anonimoweb.reload();}});




                         Button    btbuscar = (Button)
                        findViewById(R.id.bt_buscar);
        
        btbuscar.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Address = "http://" + ed1.getText().toString();
				
					WebSettings webSetting = anonimoweb.getSettings();
					
				webSetting.setBuiltInZoomControls(true);
				
                                
                                
                            webSetting.supportZoom();
                            anonimoweb.invokeZoomPicker();
                            anonimoweb.loadUrl("https://www.google.com.br/");
                            ed1.setText(anonimoweb.getUrl());
                            
                                
                                
				webSetting.setJavaScriptEnabled(true);
				
				anonimoweb.setWebViewClient(new WebViewClient());
				    anonimoweb.loadUrl(Address);
				
				ActionBar actionBar = getActionBar(); 
				actionBar.setDisplayShowHomeEnabled(false);  
				actionBar.setDisplayShowTitleEnabled(false);    
				actionBar.hide();







			}
		});
    }

    
    
    
    
    
    
    
    public class WebViewClient extends android.webkit.WebViewClient
    {
     @Override
     public void onPageStarted(WebView view,
     String url, Bitmap favicon)
     
     {

      
    	 super.onPageStarted(view, url, favicon);
    	 mprogressobar.setVisibility(View.VISIBLE);   
         ed1.setText(url);
     }
     
     
     
     
     @Override
     public boolean shouldOverrideUrlLoading(WebView view, String url) 
     {

     
      view.loadUrl(url);
      return true;
     }
     @Override
     public void onPageFinished(WebView view, String url)
     {

      

      super.onPageFinished(view, url);
		 mprogressobar.setVisibility(View.GONE);
		      }

    }

    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if ((keyCode == KeyEvent.KEYCODE_BACK) && anonimoweb.canGoBack()) {
			anonimoweb.goBack();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	
	
	@Override
	
	
	
	// Menu
	public boolean onCreateOptionsMenu(Menu options) {
		options.add(0, MENU1, 0, "Mensagem");
		options.add(0, MENU2, 0, "Sair");

		// Sub Menu
		SubMenu sub = options.addSubMenu("Op珲es");
		sub.add(0, MENU3, 0, "Tela2");
		sub.add(0, MENU4, 0, "Site DevMobileBrasil");

		return super.onCreateOptionsMenu(options);

	}

	// Selecao dos menus
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {

// recupera o item selecionado
		
		case MENU1: 

// mensagem

			Toast.makeText(this, "bem vindo ao mais novo  navegador do anonimo"
			
			+ item, Toast.LENGTH_LONG)
					.show();

			return true;

		case MENU2:

 // finaliza

			finish();

			return true;




		case MENU3:
// troca de layout

			Intent geren_remot = new Intent(this, Tela2.class);
			startActivity(geren_remot);

			return true;

		case MENU4:

			blog_do_anonimo(); 
// vizita o nosso site

			return true;
		}

		return false;

	}

	// metodo que abre o browser e visita o nosso site
	void blog_do_anonimo() {

		String end = "http://androidnamao.mywapblog.com";

		Uri uri = Uri.parse(end);

		Intent it = new Intent(Intent.ACTION_VIEW, uri);

		startActivity(it);

	}



	
	
	
}
