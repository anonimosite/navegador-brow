package com.androidnamao;

public interface OnItemClickedCallBack  {
	public void onItemClicked(int position);
}
