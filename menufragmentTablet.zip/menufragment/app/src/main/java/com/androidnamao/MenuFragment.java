package com.androidnamao;
import android.app.*;
import android.os.*;
import android.support.v4.app.*;
import android.util.*;
import android.view.*;
import android.widget.*;

import android.support.v4.app.Fragment;

public class MenuFragment extends Fragment {
	
	/** Atributo de callback */
	OnItemClickedCallBack callBack;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		/** Infla o layout */
		View view = inflater.inflate(R.layout.menu, container, false);

		/** Recupera os bot�es de menu e adiciona o listener de click */
		((Button) view.findViewById(R.id.menu1)).setOnClickListener(new OnClickMenuItemListener());;
		((Button) view.findViewById(R.id.menu2)).setOnClickListener(new OnClickMenuItemListener());;
		((Button) view.findViewById(R.id.menu3)).setOnClickListener(new OnClickMenuItemListener());;
		((Button) view.findViewById(R.id.menu4)).setOnClickListener(new OnClickMenuItemListener());;
		
		/** Retorna a view para ser exibida */
		return view;
	}
	
	/** Garante que a Activity que ir� carregar o fragment implementa a interface de callback */
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		
		try {
			callBack = (OnItemClickedCallBack) activity;
		} catch (ClassCastException e) {
			Log.e("MenuFragment", activity.toString() + " must implement OnItemClickedCallBack");
		}
	}
	
	/** Listener do click do bot�o */
	protected class OnClickMenuItemListener implements View.OnClickListener {

		@Override
		public void onClick(View v) {
			/** Chama o m�todo de callback passando o id do bot�o clicado */
			callBack.onItemClicked(v.getId());
		}
	}

}
